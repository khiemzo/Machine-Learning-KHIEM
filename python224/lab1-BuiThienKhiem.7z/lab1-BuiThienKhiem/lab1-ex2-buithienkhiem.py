"""buithienkhiem-11/2/2025"""
# Nhập nhiệt độ từ bàn phím
C = float(input("Độ C: "))

# Chuyển đổi nhiệt độ từ độ C sang độ F
F = 9/5 * C + 32

# In ra kết quả
print("Độ F: ",F)
