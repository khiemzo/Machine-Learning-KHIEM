"""buithienkhiem-11/2/2025"""
print("++++++++++++++++")
print("+Bùi Thiện Khiêm +")
print("+ Hello World! +++")
print("++++++++++++++++")