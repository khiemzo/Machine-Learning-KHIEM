"""buithienkhiem-11/2/2025"""
# Nhập 2 số nguyên từ bàn phím
x = int(input("x ? "))
y = int(input("y? "))

# Tính toán và in ra kết quả
print(f"{x} + {y} = {x + y}")
print(f"{x} - {y} = {x - y}")
print(f"{x} x {y} = {x * y}")
print(f"{x} / {y} = {x / y}")
print(f"{x} // {y} = {x // y}")
print(f"{x} % {y} = {x % y}")
